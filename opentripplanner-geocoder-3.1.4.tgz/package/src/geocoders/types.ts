// Prettier does not support typescript annotation
// eslint-disable-next-line prettier/prettier
import type { LonLatInput } from "@conveyal/lonlat"
import type { Feature, FeatureCollection } from "geojson"
import { OfflineResponse } from "../apis/offline";

type Rect = {
  maxLat: number;
  maxLon: number;
  minLat: number;
  minLon: number;
};

type Boundary = {
  country?: string;
  rect?: Rect;
};

// These settings get added to the request to the geocoder
export type GeocoderConfig = {
  apiKey?: string;
  baseUrl?: string;
  boundary?: Boundary;
  enableSlowFullUnicodeSupport?: boolean;
  focusPoint?: LonLatInput;
  layers?: string;
  options?: RequestInit;
  reverseUseFeatureCollection?: boolean;
  size?: number;
  sources?: string;
  typesWithoutSecondaryLabel?: string[]
};

export type ReverseQuery = {
  apiKey?: string;
  format?: boolean;
  options?: RequestInit;
  point?: LonLatInput;
  url?: string;
  sources?: string;
};

export type AutocompleteQuery = {
  apiKey?: string;
  boundary?: Boundary;
  focusPoint?: LonLatInput;
  format?: boolean;
  items?: OfflineResponse
  layers?: string;
  options?: RequestInit;
  size?: number;
  sources?: string | null;
  text?: string;
  url?: string;
};

export type SearchQuery = {
  apiKey?: string;
  boundary?: Boundary;
  layers?: string;
  focusPoint?: LonLatInput;
  format?: boolean;
  options?: RequestInit;
  size?: number;
  text?: string;
  url?: string;
  sources?: string | null;
};

export type AnyGeocoderQuery = SearchQuery & AutocompleteQuery & ReverseQuery;

export type MultiGeocoderResponse = FeatureCollection & {
  isomorphicMapzenSearchQuery?: AnyGeocoderQuery;
};

export type SingleGeocoderResponse = {
  isomorphicMapzenSearchQuery?: AnyGeocoderQuery;
  lat: number;
  lon: number;
  name: string;
  rawGeocodedFeature: Feature;
};

export type SingleOrMultiGeocoderResponse = MultiGeocoderResponse | SingleGeocoderResponse;