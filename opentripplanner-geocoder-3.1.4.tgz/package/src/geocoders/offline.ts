import Geocoder from "./abstract-geocoder";
// Prettier does not support typescript annotation
// eslint-disable-next-line prettier/prettier
import type { AutocompleteQuery, SearchQuery } from "..";
import { MultiGeocoderResponse } from "./types";
import { OfflineResponse } from "../apis/offline";

type OfflineQueryExtras = { enableSlowFullUnicodeSupport?: boolean }

/**
 * Geocoder implementation for an offline geocoder.
 *
 * @extends Geocoder
 */
export default class OfflineGeocoder extends Geocoder {
  getAutocompleteQuery(query: AutocompleteQuery): AutocompleteQuery & OfflineQueryExtras  {
    return {
      ...query,
      enableSlowFullUnicodeSupport: this.geocoderConfig.enableSlowFullUnicodeSupport
    };
  }

  getSearchQuery(query: SearchQuery): SearchQuery & OfflineQueryExtras {
    return {
      ...query,
      enableSlowFullUnicodeSupport: this.geocoderConfig.enableSlowFullUnicodeSupport
    };
  }

  rewriteAutocompleteResponse(response: OfflineResponse): MultiGeocoderResponse {
    return {
      features: response?.map((r, index) => ({
        geometry: { type: "Point", coordinates: [r.lon, r.lat] },
        properties: {
          ...r,
          id: `custom-${index}`,
          label: r.label,
          // If enough address info is present, enable clients to read result as a venue
          layer: r?.street || r?.neighbourhood || r?.locality || r?.region_a ? "venue" : "custom",
          name: r.label,
          source: "offline"
        },
        type: "Feature"
      })),
      type: "FeatureCollection"
    };
  }


  rewriteSearchResponse(response: OfflineResponse): MultiGeocoderResponse {
    return this.rewriteAutocompleteResponse(response);
  }
}
