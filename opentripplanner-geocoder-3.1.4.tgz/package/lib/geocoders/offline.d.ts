import Geocoder from "./abstract-geocoder";
import type { AutocompleteQuery, SearchQuery } from "..";
import { MultiGeocoderResponse } from "./types";
import { OfflineResponse } from "../apis/offline";
type OfflineQueryExtras = {
    enableSlowFullUnicodeSupport?: boolean;
};
/**
 * Geocoder implementation for an offline geocoder.
 *
 * @extends Geocoder
 */
export default class OfflineGeocoder extends Geocoder {
    getAutocompleteQuery(query: AutocompleteQuery): AutocompleteQuery & OfflineQueryExtras;
    getSearchQuery(query: SearchQuery): SearchQuery & OfflineQueryExtras;
    rewriteAutocompleteResponse(response: OfflineResponse): MultiGeocoderResponse;
    rewriteSearchResponse(response: OfflineResponse): MultiGeocoderResponse;
}
export {};
//# sourceMappingURL=offline.d.ts.map