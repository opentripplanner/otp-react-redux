export type OfflineResponse = {
    label: string;
    lat: number;
    lon: number;
    street?: string;
    neighbourhood?: string;
    locality?: string;
    region_a?: string;
    synonyms?: string[];
}[];
type OfflineQuery = {
    items: OfflineResponse;
    text?: string;
    enableSlowFullUnicodeSupport?: boolean;
};
/**
 * Search for an address using offline geocoder
 *
 * @param  {Object} $0
 * @param  {string} $0.text query
 * @para   {Object} $0.items list of items to search
 * @return {Promise}        A Promise that'll get resolved with the autocomplete result
 */
declare function autocomplete({ items, text, enableSlowFullUnicodeSupport }: OfflineQuery): Promise<OfflineResponse>;
declare function search(args: OfflineQuery): Promise<OfflineResponse>;
declare function reverse(): Promise<unknown>;
export { autocomplete, reverse, search };
//# sourceMappingURL=index.d.ts.map