import type { AutocompleteQuery, SearchQuery } from "../../geocoders/types";
type OTPGeocoderStop = {
    agencies?: {
        id: string;
        name: string;
    }[];
    code?: string;
    coordinate: {
        lat: number;
        lon: number;
    };
    feedPublisher?: {
        name: string;
    };
    id: string;
    modes: string[];
    name: string;
    type: "STOP" | "STATION";
};
type OTPGeocoderResponse = {
    results: {
        primary: OTPGeocoderStop;
        secondaries: OTPGeocoderStop[];
    }[];
} | undefined;
/**
 * Search for an address using
 * OTP Geocoder
 *
 * @param  {Object} $0
 * @param  {string} $0.url        The OTP instance, ending with /default/
 * @param  {string} $0.text       query
 * @param  {string} $0.focusPoint coordinates to center search around
 * @return {Promise}              A Promise that'll get resolved with the autocomplete result
 */
declare function autocomplete({ url, focusPoint, text }: AutocompleteQuery): Promise<OTPGeocoderResponse>;
declare function search(args: SearchQuery): Promise<OTPGeocoderResponse>;
declare function reverse(): Promise<OTPGeocoderResponse>;
export { autocomplete, reverse, search };
export type { OTPGeocoderResponse };
//# sourceMappingURL=index.d.ts.map