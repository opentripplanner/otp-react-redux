import type { AutocompleteQuery, GeocoderConfig, ReverseQuery, SearchQuery, SingleGeocoderResponse } from "./geocoders/types";
declare const getGeocoder: any;
export default getGeocoder;
export type { AutocompleteQuery, GeocoderConfig, ReverseQuery, SearchQuery, SingleGeocoderResponse };
//# sourceMappingURL=index.d.ts.map